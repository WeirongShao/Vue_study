<template>
  <div>
      <!-- 唯一根元素 -->
      <p>组件:{{ title }}-{{ num }}</p>
      <div>
          <p>{{ count }}</p>
          <button @click="count +=1 ">按钮</button>
      </div>
      <button @click="sendMessageHandle">传递数据</button>
  </div>
</template>

<script>
export default {
    data(){
        return{
            count:0,
            message:"我是Hello的数据"
        }
    },
    props:{
        title:{
            type:String,
            default:"默认数据"
        },
        num:{
            type:Number,
            default:0
        }
    },
    methods:{
        sendMessageHandle(){
            this.$emit("onMyEvent",this.message)
        }
    }
}
</script>

<style>

</style>