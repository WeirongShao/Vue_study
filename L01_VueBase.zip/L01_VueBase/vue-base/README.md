## Vue开发环境构建
### 相关环境
1. Node:https://nodejs.org/en/
2. npm镜像cnpm:npm install -g cnpm --registry=https://registry.npm.taobao.org
3. webpack:构建工具
4. 开发工具：vsCode：https://code.visualstudio.com/
5. 高亮现实：扩展 -> 搜索：Vetur

### 搭建Vue环境
1. 安装vuecli工具
```js
npm install -g @vue/cli
vue create my-project
npm run serve
```

## Vue的基础知识
1. 模版语法
    1. 插值
        1. 文本: {{ }}
        2. 原始HTML: v-html
        3. 属性: v-bind:attr
        4. 模版语法使用限制: 每个绑定都只能包含单个表达式
    2. 指令
    3. 缩写
        1. v-bind:缩写 -> :

2. 条件渲染
    1. v-if
    2. v-else
    3. template
    4. v-show

3. 列表渲染
    1. v-for
    2. 数组的更新检测

4. 事件处理
    1. v-on:click
    2. methods:承载事件函数
    3. v-on: -> @
    4. 事件传递参数
    5. 修饰符

5. 表单输入与绑定
    1. v-model
    2. 修饰符
        .lazy
        .number
        .trim
6. 计算属性vs侦听器
    1. computed
    2. watch

7. Class 与 Style 绑定
    1. 数组
    2. 对象

8. 组件基础
    1. 创建组件
    2. 引用组件
    3. 组件是独立实例化，data必须是一个函数
    4. props: 父传子
    5. 自定义事件: 子传父
