<template>
  <div id="app">
    <MyComponent>
      <template v-slot:header>
        <div>{{ msg }}</div>
      </template>
      
      <template v-slot:body>
        <div>我是内容部分</div>
      </template>

      <template v-slot:footer>
        <div>我是底部</div>
      </template>
      <template v-slot:default="slotProps">
          <h3>{{ slotProps.demo }}</h3>
      </template>
    </MyComponent>
    <DyComponent />
  </div>
</template>

<script>

import MyComponent from "./components/MyComponent"
import DyComponent from "./components/DyComponent"

export default {
  name: 'App',
  data(){
    return{
      msg:"我是头部!"
    }
  },
  components: {
    MyComponent,
    DyComponent
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
