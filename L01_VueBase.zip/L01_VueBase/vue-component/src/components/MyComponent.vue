<template>
  <div>
      <h3>插槽</h3>
      <div>
          <slot name="header">默认值/缺省值</slot>
          <hr>
          <div>我是分割线</div>
          <slot name='body'>默认值/缺省值</slot>
          <hr>
          <slot name="footer">默认值/缺省值</slot>
          <slot :demo="demo"></slot>
      </div>
  </div>
</template>

<script>
export default {
    data(){
        return{
            demo:"我是demo"
        }
    }
}
</script>

<style>

</style>