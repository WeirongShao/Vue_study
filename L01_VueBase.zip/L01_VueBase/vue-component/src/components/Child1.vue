<template>
  <div>
      <h3>Child1</h3>
      <p>{{ $root.hello() }}</p>
      <p>{{ $parent.msg }}</p>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>