<template>
  <div>
      <h3>Child2</h3>
      <p>{{ msg }}</p>
      <button @click="clickHandle">修改</button>
  </div>
</template>

<script>
export default {
    data(){
        return{
            msg:"第一次呈现数据"
        }
    },
    methods:{
        clickHandle(){
            this.msg = "Hello2"
        }
    }
}
</script>

<style>

</style>