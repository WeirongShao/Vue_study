<template>
  <div class="find">
      <ul class="find-nav">
          <li>
              <router-link to="/find/follow">关注</router-link>
          </li>
          <li>
              <router-link to="/find/cookbook">食谱</router-link>
          </li>
          <li>
              <router-link to="/find/she">种草舍</router-link>
          </li>
      </ul>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.find{
    width: 100%;
    height: 30px;
    line-height: 30px;
    background: #fff;
}

.find-nav {
    overflow: hidden;
    clear: both;
    width: 40%;
    margin: 0 auto;
    margin-top: 10px;
}

.find-nav li {
    float: left;
    width: 33.33%;
}

.active {
    color: green;
}
</style>