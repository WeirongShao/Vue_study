import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Cart from "../views/Cart.vue"
import Find from "../views/Find.vue"
import Order from "../views/Order.vue"
import User from "../views/User.vue"

import Follow from "../views/findsub/follow.vue"
import CookBook from "../views/findsub/cookbook.vue"
import She from "../views/findsub/she.vue"

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/find',
    name: 'Find',
    redirect:"/find/follow",
    component: Find,
    children:[
      {
        path:"follow",
        component:Follow
      },
      {
        path:"cookbook",
        component:CookBook
      },
      {
        path:"she",
        component:She
      }
    ]
  },
  {
    path: '/cart',
    name: 'Cart',
    component: Cart
  },
  {
    path: '/order',
    name: 'Order',
    component: Order
  },
  {
    path: '/user',
    name: 'User',
    component: User
  }
]

const router = new VueRouter({
  linkActiveClass:"active",
  routes
})

export default router
