<template>
  <div>
      种草舍
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>