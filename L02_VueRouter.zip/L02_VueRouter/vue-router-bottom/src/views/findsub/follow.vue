<template>
  <div>
      关注
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>