<template>
  <div>
      购物车
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>