<template>
  <div class="home">
    首页
  </div>
</template>

<script>

export default {
  name: 'Home',
  components: {
  }
}
</script>
