## VueRouter
### 路由安装
```js
npm install vue-router --save

import VueRouter from 'vue-router'

Vue.use(VueRouter)
```

### 路由的基础使用

### 动态路由匹配

### 文件分离

### 嵌套路由

### 编程式的导航

### 命名路由

### 命名视图

### 重定向和别名

### HTML5 History 模式

## 路由进阶

### 导航守卫
1. 全局前置守卫
2. 全局解析守卫
3. 全局后置钩子
4. 路由独享的守卫
5. 组件内的守卫

### 路由元信息


### 路由懒加载