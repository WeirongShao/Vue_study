<template>
  <div id="app">
    <!-- <router-link to="/" >首页</router-link> | 
    <router-link to="/user/100001/iwen">用户</router-link> |
    <router-link to="/news">新闻</router-link>  -->
    <router-link :to="{ name:'Home' }" >首页</router-link> | 
    <router-link :to="{ name:'User',params:{ userid:'10001',name:'ime' } }">用户</router-link> |
    <router-link to="/news">新闻</router-link> 
    <router-view></router-view>
    <router-view name="ad"></router-view>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
