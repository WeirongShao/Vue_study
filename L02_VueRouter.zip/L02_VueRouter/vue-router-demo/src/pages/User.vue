<template>
  <div>
      <h3>用户中心:{{ $route.params.userid }} - {{ $route.params.name }}</h3>
      <button @click="clickHandle">去首页</button>
  </div>
</template>

<script>
export default {
  methods:{
    clickHandle(){
      // this.$router.push("/")
      // this.$router.replace("/");
      this.$router.push({ name:"Home" })
    }
  }
}
</script>

<style>

</style>