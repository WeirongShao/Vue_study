<template>
  <div>
      <h3>新闻页面</h3>
      <router-link to="/news/sports">体育</router-link> |
      <router-link to="/news/yule">娱乐</router-link>
      <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>