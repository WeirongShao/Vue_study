<template>
  <div>
      <h3>首页</h3>
  </div>
</template>

<script>
export default {
  beforeRouteEnter(to, from, next){
    // console.log(to,from);
    next()
  },
  beforeRouteLeave(to,from,next){
    // console.log(to,from);
    next()
  }
}
</script>

<style>

</style>