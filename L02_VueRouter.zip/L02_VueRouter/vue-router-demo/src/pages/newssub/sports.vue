<template>
  <div>
      <h3>体育新闻</h3>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>