import Vue from 'vue'
import VueRouter from 'vue-router'

import Home from "../pages/Home.vue"
import User from "../pages/User.vue"
import News from "../pages/News.vue"

import AD from "../pages/AD.vue"

// import Sports from "../pages/newssub/sports.vue"
// import Yule from "../pages/newssub/yule.vue"

Vue.use(VueRouter)

/**
 * 定义路由
 */
const routes = [{
        path: "/",
        name:"Home",
        alias:"/home",
        components: {
            default:Home,
            ad:AD
        },
        beforeEnter(to, from, next){
            // console.log(from);
            // console.log(to);
            next();
        }
    },
    {
        path: "/user/:userid/:name",
        name:"User",
        components: {
            default:User,
            ad:AD
        },
        meta:{
            isLogin:true
        }
    },
    {
        path: "/news",
        name:"News",
        redirect:"/news/sports",
        component:News,
        children:[
            {
                path:"sports",
                component:() => import("../pages/newssub/sports.vue")
            },
            {
                path:"yule",
                component:Yule
            }
        ]
    }
]

/**
 * 创建路由对象
 */
const router = new VueRouter({
    // mode:"history",
    mode:"hash",
    routes
})

router.beforeEach((to,from,next) =>{
    /**
     * 需要判断用户登陆
     */
    if(to.meta.isLogin){;
        // 用户是否已经登陆
        const token = true
        if(token){
            next();
        }else{
            next("/login")
        }
    }
    next(); // 允许跳转
})

router.afterEach((to,from) =>{
    // console.log(to,from);
})


export default router